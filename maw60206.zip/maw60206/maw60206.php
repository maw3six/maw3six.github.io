<?php
/*
Plugin Name: Maw Unethical
Description: Payload package for CVE-2025-60206 verification. Authorised security research only.
Version: 1.0
*/
